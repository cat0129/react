var figlet = require("figlet");
//import의 역할 (figlet이란 모듈을 가져다쓰겠다는 의미)

figlet("hello world!!", {
  font: "ghost",
  horizontalLayout: "default",
  verticalLayout: "fitted",
  width: 180,
  whitespaceBreak: true,
}, function (err, data) {
  if (err) {
    console.log("Something went wrong...");
    console.dir(err);
    return;
  }
  console.log(data);
});