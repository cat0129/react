//path 모듈: 경로 작성을 편리하게 해줌 (운영 체제에 맞게 경로 작성해주는 글로벌 모듈)

const path = require("path");

var txtPath = path.join(__dirname, "qqqq", "text.txt");
var filename = path.basename(txtPath, ".txt")

console.log(txtPath);
console.log(path.dirname(__filename));
console.log(filename);


