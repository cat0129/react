// promise 자바스크립트 자체에서 제공하는 객체 (비동기를 처리하기 위해), 3개의 상태값을 가짐
// promise (pending, fulfilled(success), rejected(fail)) : 작업이 성공하면 fulfilled 부분이 실행되고, 실패하면 rejected 부분이 실행됨

var promise = new Promise((resolve, reject)=>{
    var flg = true;
    setTimeout(()=>{
        if(flg){
            resolve("통신 성공");
        }else{
            reject("통신 실패");
        }
    }, 1000);
});
promise
    .then((data)=>{
        console.log(data);
    })
    .catch((error)=>{
        console.err(err);
    })
    .finally(()=>{
        console.log()
    })