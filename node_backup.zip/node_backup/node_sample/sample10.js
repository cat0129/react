function test(name, age){
    //ㅇㅇ님 환영합니다
    console.log(`${name}님의 나이는 ${age}입니다`);
}

test('홍길동', 30);

// = 자바에선
// public int test(String name){ return x }

//자바스크립트에선 변수에 함수를 넣는 것도 가능
const test2 = function (name, age){
    console.log(`${name}님의 나이는 ${age}입니다`);
}
test2('김철수', 25);

//선언과 동시에 호출
(function (name, age){
    console.log(`${name}님의 나이는 ${age}입니다`);
}
('박영희', 20));



