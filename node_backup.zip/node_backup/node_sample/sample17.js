//http 모듈
const http = require("http");

//http 통신을 할 수 있는 서버 만들기
const server = http.createServer((req,res)=>{
    const {method, url} = req;
    console.log(method, "===>", url);
    res.setHeader("Contents-Type", "text/plain");
    if(url=="/main"){
        res.end("this is main page");
    }else if(url=="/board"){
        res.end("this is board");
    }else{
        res.end("non exist");
    }
    res.write("hello world");
});
//ctrl+c 서버종료

server.listen(3000, ()=>{
    console.log("서버 실행 성공")
});
//어떤 프로그램을 사용하는지 구분해주는 것 = 포트 번호