//콘솔.로그는 내장되어있는 모듈, 글로벌 모듈
console.log(__dirname);
console.log(__filename);
//_가 두개 붙은 글로벌 모듈 중 dirname(directory name): 경로명, filename: 파일명까지 나옴

