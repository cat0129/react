function delay(fn, time){
    setTimeout(fn,time);
}

delay(()=>{
    console.log(1);
    delay(()=>{
        console.log(2);
        delay(()=>{
            console.log(3);
            delay(()=>{
                console.log(4);
            }, 1000);
        }, 1000);
    }, 1000);
}, 1000);

