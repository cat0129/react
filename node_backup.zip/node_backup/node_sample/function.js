const dollarConvert = (won)=>{
    console.log(`환율은 1달러당 ${won}원입니다`)
}
const yenConvert = (won)=>console.log(`환율은 1엔당 ${won}원입니다`);
module.exports = {dollarConvert, yenConvert};