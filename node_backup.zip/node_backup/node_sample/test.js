//1. 1초 뒤에 "첫번째"를 출력하고 그 다음 다시 1초 뒤에 "두번째" 출력
setTimeout(()=>{
    console.log("첫번째")
    setTimeout(()=>{
        console.log("두번째")
    }, 1000)
},1000)

function func1(callback, x, y){
    callback(x,y);
}
//2. 위 함수(func1)를 호출하고 호출 결과로 x,y의 덧셈 결과 출력
func1((x,y)=>console.log(x+y), 3, 5)

//3. func2("홍길동", 30, func3); 이 코드의 실행 결과로 "홍길동님의 나이는 30입니다"가 출력되로록 func2,3을 정의. func3을 화살표 함수로 바꾸기
function func2(name, age, func3){
    func3(name,age);
};
function func3(name, age){
    console.log(`${name}님의 나이는 ${age}입니다`)
}

func2('영희', 25, (name,age)=>{console.log(`${name}님의 나이는 ${age}입니다`)});


//4. 2개의 숫자를 받아서 덧셈, 뺄셈을 하는 함수들의 집합 모듈을 만들고 해당 모듈을 참조하여 해당 함수들을 호출
const func = module.require("./test2");

func.sum(3,5);
func.minus(3,5);