const c = require('ansi-colors');

// console.log(c.red('This is a red string!'));
// console.log(c.green('This is a green string!'));
// console.log(c.cyan('This is a cyan string!'));
// console.log(c.yellow('This is a yellow string!'));

console.log(c.green('green'));