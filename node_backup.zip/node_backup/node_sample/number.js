const dollar = 1300;
const yen = 9;

function multiple(x,y){
    console.log(x*y);
}
function time(comment, delay){
    setTimeout(()=>{console.log("안녕")}, delay);
}

module.exports = {dollar, yen, multiple, time};