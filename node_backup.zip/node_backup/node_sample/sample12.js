function test(){
    console.log("테스트 함수");
}

setTimeout(test, 1000);
//setTimeount도 글로벌 모듈

setTimeout(()=>console.log("고양이"), 2000);