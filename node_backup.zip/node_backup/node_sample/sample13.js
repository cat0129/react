function test(comment, time){
   setTimeout(comment, time);
}
test(()=>{console.log("첫번째 함수")}, 1000);
//test 함수를 만들어서 1초 뒤에 콜백함수가 실행되도록

//모듈 : 부품. 기능을 파일 단위로 쪼개놓은 것. 부품처럼 가져다 쓰기
//모듈을 만드는 방법 2가지: commonJS, ES