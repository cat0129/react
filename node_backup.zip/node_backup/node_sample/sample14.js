const map = require("./number");
console.log(map.dollar);
console.log(map.yen);
map.multiple(3,5);
map.time("안녕",2000);

const map2 = require("./function");
map2.dollarConvert(map.dollar);
map2.yenConvert(map.yen);