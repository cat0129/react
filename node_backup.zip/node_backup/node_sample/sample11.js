const sum = function(x,y){
    return x+y;
};
console.log(sum(3, 5));

//sum을 화살표 함수로 변경
const sum2 = (x,y)=>{
    return x+y;
};
console.log(sum2(3,8));

//화살표 함수
//(매개변수)=>{원하는 결과값}

const print = ()=>{
    console.log("안녕하세요");
};
print();

const sum2_1 = (x,y)=>x+y;
console.log(sum2_1(3,1));

const print_1 = ()=> 
    console.log("안녕");
print_1();

const print_2 = name=> console.log(`${name}님 안녕하세요`);
print_2('영희');

const multiple = (x,y) => console.log(x*y);
multiple(3,5);