//fs(file system 파일 입출력 모듈), http 모듈, express
const fs = require("fs");

fs.readdir("./", (err, files)=>{
    if(err){
        console.log("오류", err);
        return;
    }
        console.log(files);
});

//문자로 인코딩 방법1
fs.readFile("text1.txt", (err, data)=>{
    if(err){
        console.log(err);
        return;
    }
    console.log(data.toString());
});
//문자로 인코딩 방법2
fs.readFile("text1.txt", "utf8", (err, data)=>{
    if(err){
        console.log(err);
        return;
    }
    // console.log(data);
    fs.writeFile("text2.txt", data, (err)=>{
        if(err){
            console.log(err);
            return;
        }
        console.log("저장 성공");
    });
});

