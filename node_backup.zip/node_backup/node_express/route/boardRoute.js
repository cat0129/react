const express = require('express')
const router = express.Router();
const connection = require('../db');

router.route("/")
    .get((req,res)=>{
        const query = `select * from tbl_board`
        connection.query(query, (err, results)=>{
            if(err){
                console.error('쿼리 실행 실패:', err);
                res.status(500).send('서버 오류');
                return;
            }
            res.render('board', {list:results});
        });
    })
    .post((req,res)=>{
        var {boardNo, title, contents} = req.body;
        res.send(`번호:${boardNo}, 제목:${title}, 내용:${contents}`);
    })
router.route("/insert")
    .get((req,res)=>{
        var board = {
            message : "success"
        };
        res.render("board-insert", board);
    })

router.route("/:boardNo")
        .get((req,res)=>
            //데이터 가져오기
            res.send(`${req.params.boardNo}번 게시글 상세보기`))    
        .put((req,res)=>
            //데이터 수정
            res.send(`${req.params.boardNo}번 게시글 업데이트`))
        .delete((req,res)=>
            //데이터 삭제
            res.send(`${req.params.boardNo}번 게시글 삭제`))

module.exports = router;            