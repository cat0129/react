const express = require('express')
const router = express.Router();
const connection = require('../db');

router.route("/")
    .get((req,res)=>{
        const query = `select * from tbl_user`
        connection.query(query, (err,result)=>{
            if(err){
                console.error('쿼리 실행 실패:', err);
                res.status(500).send('서버 오류');
                return;
            }
            res.render('user', {list:result})
        })
    })
    .post((req,res)=>{
        var user = req.body;
        const query = 'insert into tbl_user values (?,?,?,?)';
        connection.query(query, [user.id, user.pwd, user.name, user.gender], (err,result)=>{
            if(err){
                console.error('쿼리 실행 실패:', err);
                return;
            }
            res.redirect("/user");
        })
    })

router.route("/add")    
    .get((req,res)=>{
        res.render('user-add')
    })

router.route("/:id")
    .get((req,res)=>{
        var id = req.params.id
        const query = `select * from tbl_user where id='${id}'`
        connection.query(query, (err,result)=>{
            if(err){
                console.error('쿼리 실행 실패:', err);
                res.status(500).send('서버 오류');
                return;
            }
            res.render('user-update', {user:result[0]})
        })    
    })    
    .put((req,res)=>{
        const query = 'update tbl_user set pwd=?, name=?, gender=? where id=?'
        connection.query(query, [user.pwd, user.name, user.gender, user.id], (err, result)=>{
            if(err){
                console.error('쿼리 실행 실패:', err);
                return;
            }
            res.redirect("/user");
        })
    })

module.exports = router;