const express = require('express')
const router = express.Router();
const connection = require('../db');

router.route("/")
    .get((req,res)=>{
        const query = `select * from tbl_student`
        connection.query(query, (err, result)=>{
            if(err){
                console.log('에러 발생:', err);
                return;
            }
            res.render("student", {stuList:result})
        })
    })

router.route("/:stuNo")  
    .get((req,res)=>{
        const query = `select * from tbl_student where stuNo=${req.params.stuNo}`
        connection.query(query, (err, result)=>{
            if(err){
                console.log('에러 발생: ', err);
                return;
            }
            res.render('stu-update', {stu: result[0]})
        })
    })  
    .put((req,res)=>{
        var stu = req.body;
        const query = 'update tbl_student set stuName=?, stuDept=?, stuGrade=? where stuNo=?'   
        connection.query(query, [stu.stuName, stu.stuDept, stu.stuGrade, stu.stuNo], (err, result)=>{
            if(err){
                console.error('쿼리 실행 실패:', err);
                return;
            }
            res.redirect("/student");
        })
    })
    .delete((req,res)=>{
        var stuNo = req.params.stuNo
        const query = `delete from tbl_student where stuNo=${stuNo}`
        connection.query(query, (err, result)=>{
            if(err){
                console.error('쿼리 실행 실패:', err);
                return;
            }
            res.redirect("/student");
        })
    })

module.exports = router;    